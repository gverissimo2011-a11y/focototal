create database focototal;
use focototal